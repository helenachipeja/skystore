<div class="container-fluid bg-dark text-secondary mt-5 pt-5">
        <div class="row px-xl-5 pt-5">
            <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5">
                <h5 class="text-secondary text-uppercase mb-4">Entre em Contacto</h5>
                <p class="mb-4">Estamos aqui para ajudar! Se você tiver alguma dúvida, feedback, sugestão ou precisar de assistência, não hesite em entrar em contato conosco.</p>
                <p class="mb-2"><i class="fa fa-map-marker-alt text-primary mr-3"></i>Av. Karl Marx, Maputo, Moçambique</p>
                <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i>skystore@gmail.com</p>
                <p class="mb-0"><i class="fa fa-phone-alt text-primary mr-3"></i>+258 345 67890</p>
            </div>
            <div class="col-lg-8 col-md-12">
                <div class="row">
                    <div class="col-md-4 mb-5">
                        <h5 class="text-secondary text-uppercase mb-4">Acesso Rapido</h5>
                        <div class="d-flex flex-column justify-content-start">
                            <a class="text-secondary mb-2" href="<?php echo e(asset('/')); ?>"><i class="fa fa-angle-right mr-2"></i>Inicio</a>
                            <a class="text-secondary mb-2" href="<?php echo e(asset('shop')); ?>"><i class="fa fa-angle-right mr-2"></i>Nossa Loja</a>
                            <a class="text-secondary mb-2" href="<?php echo e(asset('detail')); ?>"><i class="fa fa-angle-right mr-2"></i>Detalhes da loja</a>
                            <a class="text-secondary mb-2" href="<?php echo e(asset('cart')); ?>"><i class="fa fa-angle-right mr-2"></i>Carrinho de compras</a>
                            <a class="text-secondary mb-2" href="<?php echo e(asset('checkout')); ?>"><i class="fa fa-angle-right mr-2"></i>Finalizar a Compra</a>
                            <a class="text-secondary" href="<?php echo e(asset('contact')); ?>"><i class="fa fa-angle-right mr-2"></i>Fale Conosco
                        </div>
                    </div>
                    <div class="col-md-4 mb-5">
                        <h5 class="text-secondary text-uppercase mb-4">Ajuda e Suporte</h5>
                        <div class="d-flex flex-column justify-content-start">
                            <a class="text-secondary mb-2" href="#"><i class="fa fa-angle-right mr-2"></i>Prazos e Locais de Entrega</a>
                            <a class="text-secondary mb-2" href="#"><i class="fa fa-angle-right mr-2"></i>Politica de Privacidade</a>
                            <a class="text-secondary mb-2" href="#"><i class="fa fa-angle-right mr-2"></i>Politica de Troca e Devolução</a>
                            <a class="text-secondary mb-2" href="#"><i class="fa fa-angle-right mr-2"></i>Termos e Condiçoes de Uso</a>
                            <a class="text-secondary mb-2" href="#"><i class="fa fa-angle-right mr-2"></i>Serviços</a>
                            <a class="text-secondary" href="#"><i class="fa fa-angle-right mr-2"></i>Trabalhe Conosco</a>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5">
                        <h5 class="text-secondary text-uppercase mb-4">boletim informativo</h5>
                        <p>Junte-se à nossa comunidade de assinantes e aproveite todas as vantagens que temos a oferecer.</p>
                        <form action="">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Teu Email">
                                <div class="input-group-append">
                                    <button class="btn btn-primary">inscreva-se</button>
                                </div>
                            </div>
                        </form>
                        <h6 class="text-secondary text-uppercase mt-4 mb-3">Segue-nos</h6>
                        <div class="d-flex">
                            <a class="btn btn-primary btn-square mr-2" href="#"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-primary btn-square mr-2" href="#"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-primary btn-square mr-2" href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a class="btn btn-primary btn-square" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row border-top mx-xl-5 py-4" style="border-color: rgba(256, 256, 256, .1) !important;">
            <div class="col-md-6 px-xl-0">
                <p class="mb-md-0 text-center text-md-left text-secondary">
                    &copy; <a class="text-primary" href="#"></a>Todos os direitos reservados. Projetado
                    por
                    <a class="text-primary" href="https://htmlcodex.com">SkyStore</a>
                </p>
            </div>
            <div class="col-md-6 px-xl-0 text-center text-md-right">
                <img class="img-fluid" src="img/payments.png" alt="">
            </div>
        </div>
    </div>
<?php /**PATH C:\sky-business\sky\resources\views/footer.blade.php ENDPATH**/ ?>